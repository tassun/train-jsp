import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class QueryServlet extends HttpServlet {
	public void doPost(HttpServletRequest request,HttpServletResponse response)
		throws ServletException, IOException {
			doGet(request, response);
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String sql = request.getParameter("sql");
		System.out.println("sql : "+sql);
		if(sql!=null && !sql.trim().equals("")) {
			try {
			String driver = "com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://127.0.0.1:3306/refdb";
			String user = "root";
			String password  = "root";
			Class.forName(driver);
			java.sql.Connection conn = java.sql.DriverManager.getConnection(url,user,password);
			java.sql.Statement stm = conn.createStatement();
			java.sql.ResultSet rs = stm.executeQuery(sql);
			java.sql.ResultSetMetaData met = rs.getMetaData();
			out.println("<table border=1>");
			out.println("<tr>");
			for(int i=1,isz=met.getColumnCount();i<=isz;i++) {
				String colname = met.getColumnName(i);
				out.println("<th>"+colname+"</th>");
			}
			out.println("</tr>");
			while(rs.next()) {
				out.println("<tr>");
				for(int i=1,isz=met.getColumnCount();i<=isz;i++) {
					String colname = met.getColumnName(i);
					out.println("<td>"+rs.getString(colname)+"</td>");
				}
				out.println("</tr>");
			}
			out.println("</table>");
			} catch(Exception ex) { ex.printStackTrace(); }
		}
	}
}